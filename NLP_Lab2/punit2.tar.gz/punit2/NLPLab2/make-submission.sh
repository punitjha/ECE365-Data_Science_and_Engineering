tar cvzf pset1-submission.tgz `cat manifest.txt`
